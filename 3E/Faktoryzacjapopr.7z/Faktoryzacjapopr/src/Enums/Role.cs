﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Faktoryzacjapopr.src.Enums
{
    public enum Role { Administrator, Manager, User }
}

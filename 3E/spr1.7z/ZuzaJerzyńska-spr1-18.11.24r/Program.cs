﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace spr1_18._11._24r
{
	internal class Program
	{
		public interface IAnimal
		{
			void MakeSound();
			void Eat();
		}

		public abstract class Animal : IAnimal
		{
			public string Name { get; set; }
			public string Species { get; set; }
			public int Age { get; set; }
			public string Owner { get; set; }

			public Animal(string name, string species, int age, string owner)
			{
				Name = name;
				Species = species;
				Age = age;
				Owner = owner;
			}

			public void Eat()
			{
				Console.WriteLine($"{Name} je");
			}
			public abstract void MakeSound();
		}

		public class Dog : Animal
		{
			public Dog(string Name, string Species, int age, string owner) : base(Name, Species, age, owner) { }
			public override void MakeSound()
			{
				Console.WriteLine("Hau!");
			}
		}

		public class Cat : Animal
		{
			public Cat(string Name, string Species, int age, string owner) : base(Name, Species, age, owner) { }
			public override void MakeSound()
			{
				Console.WriteLine("Miau!");
			}
		}

		static void Main(string[] args)
		{
			Animal azor = new Dog("Azor", "Pies", 2, "Jan Kowalski");
			Animal filemon = new Cat("Filemon", "Kot", 3, "Anna Nowak");
			Animal reksio = new Dog("Reksio", "Pies", 4, "Piotr Wiśniewski");
			Animal mruczek = new Cat("Mruczek", "Kot", 1, "Katarzyna Zielińska");

			//azor.Eat();
			//azor.MakeSound();

			//filemon.Eat();
			//filemon.MakeSound();

			//reksio.Eat();
			//reksio.MakeSound();

			//mruczek.Eat();
			//mruczek.MakeSound();

			List<Animal> animals = new List<Animal>();
			animals.Add(azor);
			animals.Add(filemon);
			animals.Add(reksio);
			animals.Add(mruczek);

			//foreach (Animal animal in animals)
			//{
			//	animal.Eat();
			//	animal.MakeSound();
			//}


			Console.WriteLine("Lista posortowana według właściciela");
			var SortOwner = animals.OrderBy(b => b.Owner);
			foreach (Animal anim in SortOwner)
			{
				Console.WriteLine(anim);
			}

			Console.WriteLine("Lista posortowana według gatunku");
			var SortSpecies = animals.OrderBy(b => b.Species);
			foreach (Animal anim in SortSpecies)
			{
				Console.WriteLine(anim);
			}

			Console.WriteLine("Lista posortowana według wieku");
			var SortAge = animals.OrderBy(b => b.Age);
			foreach (Animal anim in SortAge)
			{
				Console.WriteLine(anim);
			}

			Console.WriteLine("Lista posortowana według imienia");
			var SortName = animals.OrderBy(b => b.Name);
			foreach (Animal anim in SortName)
			{
				Console.WriteLine(anim);
			}

			////Menu:

			Console.WriteLine("1.Sortowanie według właściciela");
			Console.WriteLine("2.Sortowanie według gatunku");
			Console.WriteLine("3.Sortowanie według wieku");
			Console.WriteLine("4.Sortowanie według imienia");
			Console.WriteLine("5.Wyjście");

			int choice = int.Parse(Console.ReadLine());
			bool w = true;
			while (w)
			{
				switch (choice)
				{
					case 1:
						Console.WriteLine(SortName);
						break;
					case 2:
						Console.WriteLine(SortSpecies);
						break;
					case 3:
						Console.WriteLine(SortAge);
						break;
					case 4:
						Console.WriteLine(SortName);
						break;
					case 5:
						w = false;
						break;
					default:
						Console.WriteLine("Nie wybrano. Spróbuj ponownie.");
						break;
				}
			}
		}
	}
}
